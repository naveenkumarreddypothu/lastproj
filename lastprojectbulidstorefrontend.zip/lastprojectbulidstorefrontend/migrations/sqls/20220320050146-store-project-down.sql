DROP TABLE Product;

