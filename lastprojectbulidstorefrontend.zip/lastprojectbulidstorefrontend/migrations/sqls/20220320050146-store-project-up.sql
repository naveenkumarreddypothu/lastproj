CREATE TABLE Product(
    id SERIAL PRIMARY KEY,
    name VARCHAR(20),
    price INTEGER);