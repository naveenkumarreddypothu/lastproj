DROP TABLE Orders_product;
